#!/bin/bash

./catchsignal.sh &
./catchsignal.sh &
